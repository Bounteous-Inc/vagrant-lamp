#ifdef PHP_WIN32
# include "config.w32.h"
#else
# include <php_config.h>
#endif
#include <php_stdint.h>
#define TIMELIB_OMIT_STDINT 1
